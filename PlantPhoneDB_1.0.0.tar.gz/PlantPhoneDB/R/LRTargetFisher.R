#' @title Functional category enrichment analysis
#' @param Targets User input genes of interest.
#' @param GeneSets KEGG gene sets. (Ma et al., Nucleic Acids Research, 2021).
#' @param TotalGene Unique detected genes from a scRNA-seq dataset.
#'
#' @return A list. p value and overlapping genes.
#' @export
LRTargetFisher <- function(Targets,GeneSets,TotalGene){
  a <- intersect(Targets,GeneSets)
  b <- setdiff(GeneSets,a)
  c <- setdiff(Targets,a)
  abc <- union(a,b)
  abc <- union(abc,c)
  d <- setdiff(TotalGene,abc)
  tbl <- matrix(c(length(a), length(b), length(c), length(d)), nrow = 2)
  fisher <- fisher.test(tbl, alternative = "two.sided", simulate.p.value=TRUE)
  pvalue <- fisher$p.value
  overlap <- paste(a,collapse = ", ")
  return(list(pvalue=pvalue,overlap=overlap))
}
